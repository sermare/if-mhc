# External scoring of the T=0.3 SKEMPI designs

Same protocol as `designs/skempi/t01/scores.zip`, applied to the T=0.3 phase:
every unique designed epitope scored by **MHCflurry 2.2.0**
(`models_class1_presentation`) and **ESMCBA** (per-allele ESM-C 300M,
`smares/ESMCBA`). 143,167 unique peptides -- 13x the T=0.1 set -- over the same
21 complexes with a class I allele both predictors support.

| file | contents |
|---|---|
| `designs_scored.csv` | 165,201 (complex, arm, model, peptide) rows with sampling count and both scores |
| `mhcflurry_scores.csv` | 143,167 unique (peptide, allele) -> affinity (nM), presentation_score |
| `esmcba_scores.csv` | same peptides -> ESMCBA regression output |
| `native_*.csv` | the 21 native epitopes, as the reference point |
| `panel_replication_positions.csv` | per (complex, model, arm, position) recovery / chemistry match / entropy |
| `skempi_ddg_vs_recovery_*.csv` | measured SKEMPI ddG joined to recovery and entropy |

Score directions are unchanged from T=0.1: MHCflurry `affinity` is nM (lower =
stronger, <500 nM the conventional binder threshold); ESMCBA is calibrated
against it at Spearman **+0.818** over 143k peptides, so **higher ESMCBA =
weaker binding**.

## Not included

The 960-d ESMCBA embeddings are 526 MB (`esmcba_emb_A0201` alone is 485 MB),
past GitHub's per-file limit even compressed. They stay on scratch at
`outputs/skempi_if/esmcba_emb_<allele>_skempi_T0.3.npy`; row order is the sorted
unique peptides for that allele. Regenerate with
`SK_DATASET=skempi SK_TEMP=0.3 python py/score_esmcba.py`.

## What T=0.3 showed

Every panel conclusion is unchanged from T=0.1 while unique sequences per cell
rose ~11x (64->1482 for ESM-IF). Four tests became *more* significant on the
same effect sizes, so T=0.3 is the sharper estimator of the same quantity, not
merely a robustness check. Removing the TCR still yields better predicted MHC
binders in all four models, though on ESMCBA the effect weakens for the two
ProteinMPNN variants at this temperature while MHCflurry stays significant.
